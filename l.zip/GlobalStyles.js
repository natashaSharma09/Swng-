/* fonts */
export const FontFamily = {
  sFProTextSemibold: "SF Pro Text_semibold",
  robotoRegular: "Roboto_regular",
  poppinsBold: "Poppins_bold",
  poppinsMedium: "Poppins_medium",
  poppinsSemibold: "Poppins_semibold",
  robotoBold: "Roboto_bold",
  rubikRegular: "Rubik_regular",
  rubikBold: "Rubik_bold",
  robotoBlack: "Roboto_black",
};
/* font sizes */
export const FontSize = {
  size_mini: 15,
  size_smi: 13,
  size_lgi_1: 19,
  size_sm: 14,
  size_3xl: 22,
  size_xl: 20,
};
/* Colors */
export const Color = {
  white: "#fff",
  black: "#000",
  firebrick: "#cf2e2e",
  darkgray: "#969696",
  whitesmoke: "#f6f6f6",
  dimgray: "#4e4949",
  gray: "#898989",
  darkslategray: "#1c2d40",
  gainsboro: "#d9d9d9",
};
/* border radiuses */
export const Border = {
  br_23xl: 42,
  br_3xs: 10,
  br_xl: 20,
  br_sm: 14,
};
