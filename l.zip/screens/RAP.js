import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const RAP = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.rap}>
      <View style={[styles.statusBar, styles.uiIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.statusBarPosition]}
          resizeMode="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.statusIcons}>
          <Image
            style={styles.networkSignalLight}
            resizeMode="cover"
            source={require("../assets/network-signal-light.png")}
          />
          <Image
            style={[styles.wifiSignalLight, styles.lightSpaceBlock]}
            resizeMode="cover"
            source={require("../assets/wifi-signal--light.png")}
          />
          <Image
            style={[styles.batteryLight, styles.lightSpaceBlock]}
            resizeMode="cover"
            source={require("../assets/battery--light.png")}
          />
        </View>
        <Image
          style={[styles.indicatorIcon, styles.timePosition]}
          resizeMode="cover"
          source={require("../assets/indicator.png")}
        />
        <Image
          style={styles.timeLight}
          resizeMode="cover"
          source={require("../assets/time--light.png")}
        />
      </View>
      <View style={[styles.time, styles.timePosition]}>
        <Text style={styles.time1}>9:27</Text>
      </View>
      <Image
        style={styles.swngLogoTransparentCmyk12}
        resizeMode="cover"
        source={require("../assets/swng-logo-transparent-cmyk1-2.png")}
      />
      <Image
        style={styles.swngLogoTransparentCmyk12}
        resizeMode="cover"
        source={require("../assets/swng-logo-transparent-cmyk1-2.png")}
      />
      <Image
        style={[styles.uiIcon, styles.uiIconPosition]}
        resizeMode="cover"
        source={require("../assets/ui.png")}
      />
      <Image
        style={styles.rapChild}
        resizeMode="cover"
        source={require("../assets/rectangle-8.png")}
      />
      <Pressable
        style={[styles.chat, styles.chatLayout]}
        onPress={() => navigation.navigate("Ref")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/messeage.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.home, styles.chatLayout]}
        onPress={() => navigation.navigate("Home")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/home-icon.png")}
        />
      </Pressable>
      <Image
        style={[styles.starIcon, styles.chatLayout]}
        resizeMode="cover"
        source={require("../assets/star.png")}
      />
      <Pressable
        style={[styles.tick1, styles.chatLayout]}
        onPress={() => navigation.navigate("Attendence")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/tick.png")}
        />
      </Pressable>
      <Text
        style={[styles.userRating, styles.userRatingTypo]}
      >{`User Rating `}</Text>
      <Image
        style={styles.rapItem}
        resizeMode="cover"
        source={require("../assets/line-1.png")}
      />
      <Image
        style={styles.image2Icon}
        resizeMode="cover"
        source={require("../assets/image-2.png")}
      />
      <Text
        style={[styles.writeAReview, styles.userRatingTypo]}
      >{`Write a review for the user `}</Text>
      <Image
        style={styles.rapInner}
        resizeMode="cover"
        source={require("../assets/rectangle-43.png")}
      />
      <Image
        style={styles.unsplashjmurdhtm7ngIcon}
        resizeMode="cover"
        source={require("../assets/unsplashjmurdhtm7ng.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  uiIconPosition: {
    right: 4,
    position: "absolute",
  },
  statusBarPosition: {
    top: 0,
    overflow: "hidden",
  },
  lightSpaceBlock: {
    marginLeft: 4,
    height: 14,
  },
  timePosition: {
    top: 8,
    position: "absolute",
  },
  chatLayout: {
    height: 50,
    width: 50,
    position: "absolute",
  },
  userRatingTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    fontSize: 19,
    left: 33,
    color: Color.black,
    position: "absolute",
  },
  notchIcon: {
    right: -15,
    left: 15,
    maxWidth: "100%",
    height: 30,
    position: "absolute",
  },
  networkSignalLight: {
    width: 20,
    height: 14,
  },
  wifiSignalLight: {
    width: 16,
  },
  batteryLight: {
    width: 25,
  },
  statusIcons: {
    top: 16,
    right: 14,
    flexDirection: "row",
    alignItems: "center",
    position: "absolute",
  },
  indicatorIcon: {
    right: 71,
    width: 6,
    height: 6,
  },
  timeLight: {
    top: 12,
    left: 21,
    borderRadius: Border.br_xl,
    height: 21,
    width: 54,
    position: "absolute",
    overflow: "hidden",
  },
  statusBar: {
    left: -15,
    height: 44,
    top: 0,
    overflow: "hidden",
  },
  time1: {
    marginTop: -5.5,
    top: "50%",
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    fontWeight: "600",
    fontFamily: FontFamily.sFProTextSemibold,
    textAlign: "center",
    color: Color.black,
    left: 0,
    width: 54,
    position: "absolute",
  },
  time: {
    left: 1,
    width: 56,
    height: 23,
  },
  swngLogoTransparentCmyk12: {
    top: 54,
    left: 4,
    borderRadius: Border.br_23xl,
    width: 184,
    height: 84,
    position: "absolute",
  },
  uiIcon: {
    top: 9,
    width: 68,
    height: 16,
  },
  rapChild: {
    top: 831,
    width: 414,
    height: 65,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  chat: {
    left: 224,
    top: 835,
    width: 50,
  },
  home: {
    left: 23,
    top: 837,
  },
  starIcon: {
    left: 119,
    top: 835,
    width: 50,
  },
  tick1: {
    left: 330,
    top: 835,
    width: 50,
  },
  userRating: {
    top: 167,
    width: 336,
    height: 57,
  },
  rapItem: {
    top: 206,
    left: 31,
    width: 323,
    height: 3,
    position: "absolute",
  },
  image2Icon: {
    top: 137,
    left: 173,
    width: 160,
    height: 76,
    position: "absolute",
  },
  writeAReview: {
    top: 246,
    width: 339,
    height: 71,
  },
  rapInner: {
    top: 306,
    left: 29,
    width: 337,
    height: 243,
    position: "absolute",
  },
  unsplashjmurdhtm7ngIcon: {
    top: 50,
    left: 319,
    width: 67,
    height: 68,
    position: "absolute",
  },
  rap: {
    backgroundColor: Color.white,
    flex: 1,
    height: 896,
    overflow: "hidden",
    width: "100%",
  },
});

export default RAP;
