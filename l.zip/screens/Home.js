import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const Home = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.home}>
      <View style={[styles.statusBar, styles.uiIconPosition]}>
        <Image
          style={[styles.notchIcon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/notch.png")}
        />
        <View style={styles.statusIcons}>
          <Image
            style={styles.networkSignalLight}
            resizeMode="cover"
            source={require("../assets/network-signal-light.png")}
          />
          <Image
            style={[styles.wifiSignalLight, styles.lightSpaceBlock]}
            resizeMode="cover"
            source={require("../assets/wifi-signal--light.png")}
          />
          <Image
            style={[styles.batteryLight, styles.lightSpaceBlock]}
            resizeMode="cover"
            source={require("../assets/battery--light.png")}
          />
        </View>
        <Image
          style={[styles.indicatorIcon, styles.timePosition]}
          resizeMode="cover"
          source={require("../assets/indicator.png")}
        />
        <Image
          style={[styles.timeLight, styles.timeLightLayout]}
          resizeMode="cover"
          source={require("../assets/time--light.png")}
        />
      </View>
      <View style={[styles.time, styles.timePosition]}>
        <Text style={[styles.time1, styles.time1Typo]}>9:27</Text>
      </View>
      <View style={[styles.time, styles.timePosition]}>
        <Text style={[styles.time1, styles.time1Typo]}>9:27</Text>
      </View>
      <Text style={[styles.editProfile, styles.editProfileFlexBox]}>
        Edit Profile
      </Text>
      <Text style={[styles.phoneNumber, styles.editProfileFlexBox]}>
        Phone Number
      </Text>
      <Image
        style={[styles.arrowLeftIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/arrowleft.png")}
      />
      <Image
        style={[styles.ushareAltIcon, styles.timeLightLayout]}
        resizeMode="cover"
        source={require("../assets/usharealt.png")}
      />
      <Image
        style={styles.swngLogoTransparentCmyk12}
        resizeMode="cover"
        source={require("../assets/swng-logo-transparent-cmyk1-2.png")}
      />
      <Image
        style={[styles.uiIcon, styles.uiIconPosition]}
        resizeMode="cover"
        source={require("../assets/ui.png")}
      />
      <Image
        style={styles.swngLogoTransparentCmyk12}
        resizeMode="cover"
        source={require("../assets/swng-logo-transparent-cmyk1-2.png")}
      />
      <Image
        style={[styles.homeChild, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-8.png")}
      />
      <Image
        style={[styles.homeChild, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-8.png")}
      />
      <Pressable
        style={[styles.messeage, styles.starLayout]}
        onPress={() => navigation.navigate("RAP")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/messeage.png")}
        />
      </Pressable>
      <Image
        style={[styles.homeIcon, styles.starLayout]}
        resizeMode="cover"
        source={require("../assets/home-icon.png")}
      />
      <Pressable
        style={[styles.star, styles.starLayout]}
        onPress={() => navigation.navigate("RAP")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.tick, styles.starLayout]}
        onPress={() => navigation.navigate("Attendence")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/tick.png")}
        />
      </Pressable>
      <Text
        style={[styles.upcomingEvent, styles.seeMoreTypo]}
      >{`Upcoming Event `}</Text>
      <Image
        style={[styles.homeInner, styles.homeInnerPosition]}
        resizeMode="cover"
        source={require("../assets/line-1.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.homeInnerPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-43.png")}
      />
      <Image
        style={[styles.image1Icon, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/image-1.png")}
      />
      <Text style={[styles.seeMore, styles.seeMoreTypo]}>{`See More `}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  uiIconPosition: {
    right: 4,
    position: "absolute",
  },
  iconLayout: {
    height: 30,
    position: "absolute",
  },
  lightSpaceBlock: {
    marginLeft: 4,
    height: 14,
  },
  timePosition: {
    top: 8,
    position: "absolute",
  },
  timeLightLayout: {
    height: 21,
    position: "absolute",
    overflow: "hidden",
  },
  time1Typo: {
    fontWeight: "600",
    fontSize: FontSize.size_mini,
  },
  editProfileFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  homeChildPosition: {
    width: 414,
    left: 0,
    position: "absolute",
  },
  starLayout: {
    height: 50,
    width: 50,
    position: "absolute",
  },
  seeMoreTypo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    fontSize: 19,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  homeInnerPosition: {
    left: 31,
    position: "absolute",
  },
  notchIcon: {
    right: -15,
    left: 15,
    maxWidth: "100%",
    top: 0,
    overflow: "hidden",
  },
  networkSignalLight: {
    width: 20,
    height: 14,
  },
  wifiSignalLight: {
    width: 16,
  },
  batteryLight: {
    width: 25,
  },
  statusIcons: {
    top: 16,
    right: 14,
    flexDirection: "row",
    alignItems: "center",
    position: "absolute",
  },
  indicatorIcon: {
    right: 71,
    width: 6,
    height: 6,
  },
  timeLight: {
    top: 12,
    left: 21,
    borderRadius: Border.br_xl,
    width: 54,
    height: 21,
  },
  statusBar: {
    left: -15,
    height: 44,
    top: 0,
    overflow: "hidden",
  },
  time1: {
    marginTop: -5.5,
    top: "50%",
    letterSpacing: 0,
    fontFamily: FontFamily.sFProTextSemibold,
    textAlign: "center",
    color: Color.black,
    left: 0,
    fontWeight: "600",
    fontSize: FontSize.size_mini,
    width: 54,
    position: "absolute",
  },
  time: {
    left: 1,
    width: 56,
    height: 23,
  },
  editProfile: {
    left: 155,
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    top: 54,
    fontWeight: "600",
    fontSize: FontSize.size_mini,
  },
  phoneNumber: {
    top: 462,
    left: 36,
    fontSize: FontSize.size_sm,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    display: "none",
    color: Color.black,
  },
  arrowLeftIcon: {
    top: 50,
    left: 17,
    width: 26,
  },
  ushareAltIcon: {
    top: 47,
    left: 350,
    width: 21,
  },
  swngLogoTransparentCmyk12: {
    left: 4,
    borderRadius: Border.br_23xl,
    width: 184,
    height: 84,
    top: 54,
    position: "absolute",
  },
  uiIcon: {
    top: 9,
    width: 68,
    height: 16,
  },
  homeChild: {
    top: 831,
    height: 65,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  messeage: {
    left: 224,
    top: 835,
    width: 50,
  },
  homeIcon: {
    top: 837,
    left: 23,
  },
  star: {
    left: 119,
    top: 835,
    width: 50,
  },
  tick: {
    left: 330,
    top: 835,
    width: 50,
  },
  upcomingEvent: {
    top: 169,
    left: 106,
    width: 336,
    height: 57,
  },
  homeInner: {
    top: 206,
    width: 323,
    height: 3,
  },
  rectangleIcon: {
    top: 256,
    width: 337,
    height: 243,
  },
  image1Icon: {
    top: 677,
    height: 154,
  },
  seeMore: {
    top: 513,
    left: 276,
    width: 136,
    height: 61,
  },
  home: {
    backgroundColor: Color.white,
    flex: 1,
    height: 896,
    overflow: "hidden",
    width: "100%",
  },
});

export default Home;
