import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { FontFamily, Border, Color, FontSize } from "../GlobalStyles";

const Home1 = () => {
  return (
    <View style={styles.home}>
      <View style={styles.username}>
        <View style={[styles.usernameChild, styles.childLayout]} />
        <Text style={[styles.usernameOrEMail, styles.loginTypo]}>
          Username or E-mail
        </Text>
      </View>
      <View style={styles.passowrd}>
        <View style={[styles.passowrdChild, styles.childLayout]} />
        <Text style={[styles.password, styles.loginTypo]}>Password</Text>
      </View>
      <View style={[styles.loginBtn, styles.loginLayout]}>
        <View style={[styles.loginBtnChild, styles.loginLayout]} />
        <Text style={[styles.login, styles.timeLayout]}>LogIn</Text>
      </View>
      <View style={[styles.statusBar, styles.statusBarPosition]}>
        <Image
          style={styles.uiIcon}
          resizeMode="cover"
          source={require("../assets/ui.png")}
        />
        <View style={[styles.time, styles.timeLayout]}>
          <Text style={styles.time1}>9:27</Text>
        </View>
      </View>
      <Image
        style={styles.swngLogoTransparentCmyk11}
        resizeMode="cover"
        source={require("../assets/swng-logo-transparent-cmyk1-1.png")}
      />
      <Image
        style={styles.icons8HomePage2413}
        resizeMode="cover"
        source={require("../assets/home-icon.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  childLayout: {
    height: 46,
    position: "absolute",
  },
  loginTypo: {
    height: 17,
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
  },
  loginLayout: {
    width: 133,
    height: 46,
    position: "absolute",
  },
  timeLayout: {
    width: 56,
    position: "absolute",
  },
  statusBarPosition: {
    top: 0,
    left: 0,
  },
  usernameChild: {
    top: 28,
    shadowOpacity: 1,
    elevation: 18,
    shadowRadius: 18,
    shadowOffset: {
      width: -4,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.09)",
    borderRadius: Border.br_3xs,
    backgroundColor: Color.whitesmoke,
    height: 46,
    width: 321,
    left: 0,
  },
  usernameOrEMail: {
    width: 130,
    color: Color.darkgray,
    fontSize: FontSize.size_smi,
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    top: 0,
    position: "absolute",
    left: 2,
  },
  username: {
    top: 286,
    left: 41,
    height: 74,
    width: 321,
    position: "absolute",
  },
  passowrdChild: {
    top: 22,
    left: 2,
    shadowOpacity: 1,
    elevation: 18,
    shadowRadius: 18,
    shadowOffset: {
      width: -4,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.09)",
    borderRadius: Border.br_3xs,
    backgroundColor: Color.whitesmoke,
    height: 46,
    width: 321,
  },
  password: {
    width: 67,
    color: Color.darkgray,
    fontSize: FontSize.size_smi,
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    top: 0,
    position: "absolute",
    left: 0,
  },
  passowrd: {
    top: 380,
    left: 43,
    width: 323,
    height: 68,
    position: "absolute",
  },
  loginBtnChild: {
    backgroundColor: Color.firebrick,
    top: 0,
    left: 0,
    shadowOpacity: 1,
    elevation: 18,
    shadowRadius: 18,
    shadowOffset: {
      width: -4,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.09)",
    borderRadius: Border.br_3xs,
    width: 133,
  },
  login: {
    left: 47,
    color: Color.white,
    fontSize: FontSize.size_mini,
    top: 15,
    height: 17,
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    width: 56,
  },
  loginBtn: {
    top: 527,
    left: 141,
  },
  uiIcon: {
    right: 14,
    width: 68,
    height: 16,
    top: 15,
    position: "absolute",
  },
  time1: {
    marginTop: -5.5,
    top: "50%",
    letterSpacing: 0,
    fontWeight: "600",
    fontFamily: FontFamily.sFProTextSemibold,
    color: Color.black,
    textAlign: "center",
    width: 54,
    fontSize: FontSize.size_mini,
    left: 0,
    position: "absolute",
  },
  time: {
    top: 8,
    left: 21,
    height: 23,
  },
  statusBar: {
    right: 0,
    height: 46,
    position: "absolute",
  },
  swngLogoTransparentCmyk11: {
    top: 149,
    left: 49,
    borderRadius: Border.br_23xl,
    width: 295,
    height: 128,
    position: "absolute",
  },
  icons8HomePage2413: {
    top: 846,
    left: 24,
    width: 50,
    height: 50,
    position: "absolute",
  },
  home: {
    backgroundColor: Color.white,
    flex: 1,
    width: "100%",
    height: 896,
    overflow: "hidden",
    display: "none",
  },
});

export default Home1;
